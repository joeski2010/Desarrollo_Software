
 function validar()
{
     rpt=confirm('Se Guardaran todos sus datos,Desea Continuar?');
	//modalidad=getElementById("modalidaddetallecod").value;           carrera=getElementById("carreracod").selectedIndex;
if(rpt==true)
{
	
	//PARA LA CARRERA DE ARQUITECTURA CODIGO 37
if(modalidadcod.value=="0202" && carreracod.value=="37"){
alert("La Carrera Profesional de ARQUITECTURA segun la Modalidad DEPORTISTAS CALIFICADOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}

if(modalidadcod.value=="0203" && carreracod.value=="37"){
alert("La Carrera Profesional de ARQUITECTURA segun la Modalidad VICTIMAS DEL TERRORISMO tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}

if(modalidadcod.value=="0204" && carreracod.value=="37"){
alert("La Carrera Profesional de ARQUITECTURA segun la Modalidad TITULADOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}

if(modalidadcod.value=="0205" && carreracod.value=="37"){
alert("La Carrera Profesional de ARQUITECTURA segun la Modalidad TRASLADOS INTERNOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}

if(modalidadcod.value=="0206" && carreracod.value=="37"){
alert("La Carrera Profesional de ARQUITECTURA segun la Modalidad TRASLADOS EXTERNOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0209" && carreracod.value=="37"){
alert("La Carrera Profesional de ARQUITECTURA segun la Modalidad COLEGIO PRESIDENCIAL tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}

if(modalidadcod.value=="0209" && carreracod.value=="37"){
alert("La Carrera Profesional de ARQUITECTURA segun la Modalidad COLEGIO PRESIDENCIAL tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}
//PARA LA CARRERA DE CIENCIAS BIOLOGIAS Y QUIMICAS CODIGO 09

if(modalidadcod.value=="0202" && carreracod.value=="09"){
alert("La Carrera Profesional de EDUCACION:CIENCIAS BIOLOGICAS Y QUIMICAS segun la Modalidad DEPORTISTAS CALIFICADOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0203" && carreracod.value=="09"){
alert("La Carrera Profesional de EDUCACION:CIENCIAS BIOLOGICAS Y QUIMICAS segun la Modalidad VICTIMAS DEL TERRORISMO tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0204" && carreracod.value=="09"){
alert("La Carrera Profesional de EDUCACION:CIENCIAS BIOLOGICAS Y QUIMICAS segun la Modalidad TITULADOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0205" && carreracod.value=="09"){
alert("La Carrera Profesional de EDUCACION:CIENCIAS BIOLOGICAS Y QUIMICAS segun la Modalidad TRASLADOS INTERNOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0206" && carreracod.value=="09"){
alert("La Carrera Profesional de EDUCACION:CIENCIAS BIOLOGICAS Y QUIMICAS segun la Modalidad TRASLADOS EXTERNOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0209" && carreracod.value=="09"){
alert("La Carrera Profesional de EDUCACION:CIENCIAS BIOLOGICAS Y QUIMICAS segun la Modalidad COLEGIO PRESIDENCIAL tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}

//PARA LA CARRERA DE CIENCIAS MATEMATICAS E INFORMATICAS CODIGO 07

if(modalidadcod.value=="0202" && carreracod.value=="07"){
alert("La Carrera Profesional de EDUCACION:CIENCIAS MATEMATICAS E INFORMATICAS segun la Modalidad DEPORTISTAS CALIFICADOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0203" && carreracod.value=="07"){
alert("La Carrera Profesional de EDUCACION:CIENCIAS MATEMATICAS E INFORMATICAS segun la Modalidad VICTIMAS DEL TERRORISMO tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0204" && carreracod.value=="07"){
alert("La Carrera Profesional de EDUCACION:CIENCIAS MATEMATICAS E INFORMATICAS segun la Modalidad TITULADOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0205" && carreracod.value=="07"){
alert("La Carrera Profesional de EDUCACION:CIENCIAS MATEMATICAS E INFORMATICAS segun la Modalidad TRASLADOS INTERNOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0206" && carreracod.value=="07"){
alert("La Carrera Profesional de EDUCACION:CIENCIAS MATEMATICAS E INFORMATICAS segun la Modalidad TRASLADOS EXTERNOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0209" && carreracod.value=="07"){
alert("La Carrera Profesional de EDUCACION:CIENCIAS MATEMATICAS E INFORMATICAS segun la Modalidad COLEGIO PRESIDENCIAL tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}



//PARA LA CARRERA DE EDUCACION ARTISTICA CODIGO 39

if(modalidadcod.value=="0202" && carreracod.value=="39"){
alert("La Carrera Profesional de EDUCACION: EDUCACION ARTISTICA segun la Modalidad DEPORTISTAS CALIFICADOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0203" && carreracod.value=="39"){
alert("La Carrera Profesional de EDUCACION:EDUCACION ARTISTICA segun la Modalidad VICTIMAS DEL TERRORISMO tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0204" && carreracod.value=="39"){
alert("La Carrera Profesional de EDUCACION:EDUCACION ARTISTICA segun la Modalidad TITULADOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0205" && carreracod.value=="39"){
alert("La Carrera Profesional de EDUCACION:EDUCACION ARTISTICA segun la Modalidad TRASLADOS INTERNOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0206" && carreracod.value=="39"){
alert("La Carrera Profesional de EDUCACION:EDUCACION ARTISTICA segun la Modalidad TRASLADOS EXTERNOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0209" && carreracod.value=="39"){
alert("La Carrera Profesional de EDUCACION:EDUCACION ARTISTICA segun la Modalidad COLEGIO PRESIDENCIAL tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}

//PARA LA CARRERA DE EDUCACION FISICA CODIGO 08

if(modalidadcod.value=="0202" && carreracod.value=="08"){
alert("La Carrera Profesional de EDUCACION: EDUCACION FISICA segun la Modalidad DEPORTISTAS CALIFICADOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0203" && carreracod.value=="08"){
alert("La Carrera Profesional de EDUCACION:EDUCACION FISICA segun la Modalidad VICTIMAS DEL TERRORISMO tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0204" && carreracod.value=="08"){
alert("LaCarrera Profesional de EDUCACION:EDUCACION FISICA segun la Modalidad TITULADOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0205" && carreracod.value=="08"){
alert("La Carrera Profesional de EDUCACION:EDUCACION ARTISTICA segun la Modalidad TRASLADOS INTERNOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0206" && carreracod.value=="08"){
alert("La Carrera Profesional de EDUCACION:EDUCACION ARTISTICA segun la Modalidad TRASLADOS EXTERNOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0209" && carreracod.value=="08"){
alert("La Carrera Profesional de EDUCACION:EDUCACION ARTISTICA segun la Modalidad COLEGIO PRESIDENCIAL tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}



//PARA LA CARRERA DE FILOSOFIA Y CIENCIAS SOCIALES CODIGO 10

if(modalidadcod.value=="0202" && carreracod.value=="10"){
alert("La Carrera Profesional de EDUCACION: FILOSOFIA Y CIENCIAS SOCIALES segun la Modalidad DEPORTISTAS CALIFICADOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0203" && carreracod.value=="10"){
alert("La Carrera Profesional de EDUCACION:FILOSOFIA Y CIENCIAS SOCIALES segun la Modalidad VICTIMAS DEL TERRORISMO tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0204" && carreracod.value=="10"){
alert("La Carrera Profesional de EDUCACION:FILOSOFIA Y CIENCIAS SOCIALES segun la Modalidad TITULADOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0205" && carreracod.value=="10"){
alert("La Carrera Profesional de EDUCACION:FILOSOFIA Y CIENCIAS SOCIALES segun la Modalidad TRASLADOS INTERNOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0206" && carreracod.value=="10"){
alert("La Carrera Profesional de EDUCACION:FILOSOFIA Y CIENCIAS SOCIALES segun la Modalidad TRASLADOS EXTERNOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0209" && carreracod.value=="10"){
alert("La Carrera Profesional de EDUCACION:FILOSOFIA Y CIENCIAS SOCIALES segun la Modalidad COLEGIO PRESIDENCIAL tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}


//PARA LA CARRERA DE HISTORIA Y GEOGRAFIA CODIGO 05

if(modalidadcod.value=="0202" && carreracod.value=="05"){
alert("La Carrera Profesional de EDUCACION: HISTORIA Y GEOGRAFIA segun la Modalidad DEPORTISTAS CALIFICADOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0203" && carreracod.value=="05"){
alert("La Carrera Profesional de EDUCACION:HISTORIA Y GEOGRAFIA segun la Modalidad VICTIMAS DEL TERRORISMO tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0204" && carreracod.value=="05"){
alert("La Carrera Profesional de EDUCACION:HISTORIA Y GEOGRAFIA segun la Modalidad TITULADOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0205" && carreracod.value=="05"){
alert("La Carrera Profesional de EDUCACION:HISTORIA Y GEOFRAFIA segun la Modalidad TRASLADOS INTERNOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0206" && carreracod.value=="05"){
alert("La Carrera Profesional de EDUCACION:HISTORIA Y GEOFRAFIA segun la Modalidad TRASLADOS EXTERNOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0209" && carreracod.value=="05"){
alert("La Carrera Profesional de EDUCACION:HISTORIA Y GEOFRAFIA segun la Modalidad COLEGIO PRESIDENCIAL tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}

//PARA LA CARRERA DE INGENIERIA DE ALIMENTOS CODIGO 32

if(modalidadcod.value=="0202" && carreracod.value=="32"){
alert("La Carrera Profesional de INGENIERIA DE ALIMENTOS segun la Modalidad DEPORTISTAS CALIFICADOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0203" && carreracod.value=="32"){
alert("La Carrera Profesional de INGENIERIA DE ALIMENTOS segun la Modalidad VICTIMAS DEL TERRORISMO tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0204" && carreracod.value=="32"){
alert("La Carrera Profesional de INGENIERIA DE ALIMENTOS segun la Modalidad TITULADOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0205" && carreracod.value=="32"){
alert("La Carrera Profesional de INGENIERIA DE ALIMENTOS segun la Modalidad TRASLADOS INTERNOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0206" && carreracod.value=="32"){
alert("La Carrera Profesional de INGENIERIA DE ALIMENTOS segun la Modalidad TRASLADOS EXTERNOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0209" && carreracod.value=="32"){
alert("La Carrera Profesional de INGENIERIA DE ALIMENTOS segun la Modalidad COLEGIO PRESIDENCIAL tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}

//PARA LA CARRERA DE INGENIERIA PESQUERA CODIGO 26

if(modalidadcod.value=="0202" && carreracod.value=="26"){
alert("La Carrera Profesional de INGENIERIA PESQUERA segun la Modalidad DEPORTISTAS CALIFICADOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0203" && carreracod.value=="26"){
alert("La Carrera Profesional de INGENIERIA PESQUERA segun la Modalidad VICTIMAS DEL TERRORISMO tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad.");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0204" && carreracod.value=="26"){
alert("La Carrera Profesional de INGENIERIA PESQUERA segun la Modalidad TITULADOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0205" && carreracod.value=="26"){
alert("La carrera INGENIERIA PESQUERA segun la Modalidad TRASLADOS INTERNOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0206" && carreracod.value=="26"){
alert("La Carrera Profesional de INGENIERIA PESQUERA segun la Modalidad TRASLADOS EXTERNOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0209" && carreracod.value=="26"){
alert("La Carrera Profesional de INGENIERIA PESQUERA segun la Modalidad COLEGIO PRESIDENCIAL tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad");
modalidadcod.focus();
return false;
}

//PARA LA CARRERA DE INGENIERIA PETROQUIMICA CODIGO 41

if(modalidadcod.value=="0202" && carreracod.value=="41"){
alert("La Carrera Profesional de INGENIERIA PETROQUIMICA segun la Modalidad DEPORTISTAS CALIFICADOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0203" && carreracod.value=="41"){
alert("La Carrera Profesional de INGENIERIA PETROQUIMICA segun la Modalidad VICTIMAS DEL TERRORISMO tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0204" && carreracod.value=="41"){
alert("La Carrera Profesional de INGENIERIA PETROQUIMICA segun la Modalidad TITULADOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0205" && carreracod.value=="41"){
alert("LaCarrera Profesional de INGENIERIA PETROQUIMICA segun la Modalidad TRASLADOS INTERNOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0206" && carreracod.value=="41"){
alert("La Carrera Profesional de INGENIERIA PETROQUIMICA segun la Modalidad TRASLADOS EXTERNOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0209" && carreracod.value=="41"){
alert("La Carrera Profesional de INGENIERIA PETROQUIMICA segun la Modalidad COLEGIO PRESIDENCIAL tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad");
modalidadcod.focus();
return false;
}

//PARA LA CARRERA DE OBSTETRICIA CODIGO 30

if(modalidadcod.value=="0202" && carreracod.value=="30"){
alert("La Carrera Profesional de OBSTETRICIA segun la Modalidad DEPORTISTAS CALIFICADOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0203" && carreracod.value=="30"){
alert("La Carrera Profesional de OBSTETRICIA segun la Modalidad VICTIMAS DEL TERRORISMO tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0204" && carreracod.value=="30"){
alert("La Carrera Profesional de OBSTETRICIA segun la Modalidad TITULADOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0205" && carreracod.value=="30"){
alert("La Carrera Profesional de OBSTETRICIA segun la Modalidad TRASLADOS INTERNOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0206" && carreracod.value=="30"){
alert("La Carrera Profesional de OBSTETRICIA segun la Modalidad TRASLADOS EXTERNOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0209" && carreracod.value=="30"){
alert("La Carrera Profesional de OBSTETRICIA segun la Modalidad COLEGIO PRESIDENCIAL tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad");
modalidadcod.focus();
return false;
}


//PARA LA CARRERA DE PSICOLOGIA CODIGO 35

if(modalidadcod.value=="0202" && carreracod.value=="35"){
alert("La Carrera Profesional de PSICOLOGIA segun la Modalidad DEPORTISTAS CALIFICADOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0203" && carreracod.value=="35"){
alert("La Carrera Profesional de PSICOLOGIA segun la Modalidad VICTIMAS DEL TERRORISMO tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad");
modalidaddetallecod.focus();
return false;
}
if(modalidadcod.value=="0204" && carreracod.value=="35"){
alert("La Carrera Profesional de  PSICOLOGIA segun la Modalidad TITULADOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0205" && carreracod.value=="35"){
alert("La Carrera Profesional de  PSICOLOGIA segun la Modalidad TRASLADOS INTERNOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad");
modalidadcod.focus();
return false;
}
if(modalidadcod.value=="0206" && carreracod.value=="35"){
alert("La cCarrera Profesional de  PSICOLOGIA segun la Modalidad TRASLADOS EXTERNOS tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad");
modalidadcod.focus();
return false;
}

if(modalidadcod.value=="0209" && carreracod.value=="35"){
alert("La Carrera Profesional de  PSICOLOGIA segun la Modalidad COLEGIO PRESIDENCIAL tiene 0 Vacantes,Seleccione otra carrera y/o Modalidad");
modalidadcod.focus();
return false;
}




//EN TODOS LOS DEMAS CASOS SE ENVIA EL FORMULARIO
formulario.submit();
	
 }
}
